var HomeView = function (adapter, template, listItemTemplate) {

    this.initialize = function () {
        // Define a div wrapper for the view. The div wrapper is used to attach events.
        this.el = $('<div/>');
        this.el.on('keyup', '.search-key', this.findByName);
    };

    this.render = function() {
        this.el.html(template());
        return this;
    };

    this.findByName = function() {
        //adapter.findByName($('.search-key').val())//.done(function (employees) {
            //parseRolesXml(employees);
            //$('.employee-list').html(listItemTemplate(employees));
        //});
        CallWebService();
    };

    this.initialize();

    var invocation = new XMLHttpRequest();

    function CallWebService() {
        if (invocation) {
            invocation.open('POST', 'http://cbccrmwebsite.dev1.evolvin.com/Webservices/Membership.asmx/GetAllRoles', true);
            invocation.onreadystatechange = handler;
            invocation.withCredential = "true";
            invocation.send("search=" + $('.search-key').val());
        }
    }

    function handler() {
        if (invocation.readyState == 4) {
            xmlDoc = $.parseXML(invocation.responseText);
            $xml = $(xmlDoc);
            $roles = $xml.find("string");

            var employees = parseRolesXml($roles.text());
            $('.employee-list').html(listItemTemplate(employees));
        }
    }

    function parseRolesXml(xml) {
        console.log(xml);
        xml2 = $.parseXML(xml);
        var items = [];
        //var subitems = [];

        //var PageSize = $(ControlID + '_HiddenPageSize').val();
        //var Template = $(ControlID + '_Template').val();
        //var Container = ControlID + '_Container';


        //var Count = $(xml).find("Members").length;

        //if (Count == 0) {
        //    $(ControlID + '_noresultspanel').show();

        //}
        //else {
        xmlRoles = $(xml2).find("Roles");
        
        $(xmlRoles).find("Role").each(function () {

            items.push({
                //Index: $(xml).find("Members").index(this),
                Name: $(this).find("RoleName").text(),
                //NameLink: ReplaceSpecialCharacterForUrl($(this).find("Name").text()),
                //PersonID: $(this).find("RoleID").text(),
                //Salutation: $(this).find("Salutation").text(),
                //FileName: $(this).find("FileName").text(),
                //Email: $(this).find("Email").text(),
                //RoleName: $(this).find("RoleName").text(),
                //RoleID: $(this).find("RoleID").text(),
                //Count: Count - 1,
                //ControlID: ControlID.substring(1, ControlID.length)
                //Contactmethods: subitems
                lastName: $(this).find("RoleName").text(),
                managerId: 0,
                managerName: "",
                title: "President and CEO",
                department: "Corporate",
                cellPhone: "617-000-0001",
                officePhone: "781-000-0001",
                email: "jking@fakemail.com",
                city: "Boston, MA",
                pic: "James_King.jpg",
                twitterId: "@fakejking",
                blog: "http=//coenraets.org"
            });

        });

        //my.utils.renderExternalTemplate(Template, Container, items);
        //my.utils.renderExternalTemplate(TemplateName, "#membersdirectory", items);

        //}
        return items;
    }


}