var JSONPAdapter = function() {

    this.initialize = function(data) {
        url = typeof data !== 'undefined' ? data : "http://cbccrmwebsite.dev1.evolvin.com/Webservices/Membership.asmx/GetAllRoles";
        var deferred = $.Deferred();
        deferred.resolve();
        return deferred.promise();
    }

    this.findById = function(id) {
        
    }

    this.findByName = function (searchKey) {
        
    }

    var url;

}