var JSONPAdapter = function() {

    this.initialize = function(data) {
        url = typeof data !== 'undefined' ? data : "http://mobileapptest.dev1.evolvin.com/home/index";
        var deferred = $.Deferred();
        deferred.resolve();
        return deferred.promise();
    }

    this.findById = function(id) {
        return $.ajax({url: url + "/" + id});
    }

    this.findByName = function(searchKey) {
        return $.ajax({url: url + "?name=" + searchKey});
    }

    var url;

}